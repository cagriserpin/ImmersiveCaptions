# Immersive Captions 2

Bu sürüm, altyazıları ekranın altında göstermek yerine karakterlerin yüzlerinin üstüne yerleştirmek için başlangıç iskeletidir.

## Bu sürümde neler var?

- Mevcut PySide6 video player
- OpenCV ile yüz algılama ön işleme scripti
- Yüz kutularını track id ile kaydeden basit takip mantığı
- Caption JSON içindeki `speakers.<name>.track_id` alanına göre altyazıları yüzün üstünde gösterme
- İsteğe bağlı debug yüz kutuları

## Nasıl kullanılır?

1. Video aç.
2. Caption JSON aç.
3. `Process Faces` ile video için yüz track dosyası üret.
4. Gerekirse caption JSON içindeki speaker'lara `track_id` ata.
5. Oynat ve konumları kontrol et.

## Caption JSON speaker örneği

```json
"speakers": {
  "mahmut_hoca": {
    "font_color": "#ffffff",
    "track_id": 0
  },
  "inek_saban": {
    "font_color": "#ffffff",
    "track_id": 3
  }
}
```

## Sonraki mantıklı adımlar

- track id'leri manuel atamak için küçük bir eşleme aracı yapmak
- sadece yüz değil üst gövde / kişi kutusu da çıkarmak
- SFX için ekranda serbest konum desteği eklemek
- karakter tanıtma / yüz tanıma ile otomatik speaker eşleştirme
