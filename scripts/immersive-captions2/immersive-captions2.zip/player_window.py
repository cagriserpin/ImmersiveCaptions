
from __future__ import annotations

from pathlib import Path
import sys

from PySide6.QtCore import Qt, QSettings, QTimer, QUrl
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtMultimediaWidgets import QGraphicsVideoItem
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFrame,
    QGraphicsScene,
    QGraphicsView,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QSlider,
    QVBoxLayout,
    QWidget,
)

from caption_model import CaptionModel
from caption_renderer import CaptionRenderer
from face_tracker import process_video_faces


class ClickableSlider(QSlider):
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            value = self.pixel_pos_to_range_value(int(event.position().x()))
            self.setValue(value)
            self.sliderMoved.emit(value)
            self.sliderReleased.emit()
            event.accept()
            return
        super().mousePressEvent(event)

    def pixel_pos_to_range_value(self, pos: int) -> int:
        span = self.width() if self.orientation() == Qt.Orientation.Horizontal else self.height()
        if span <= 0:
            return self.minimum()
        ratio = max(0.0, min(1.0, pos / span))
        return int(self.minimum() + ratio * (self.maximum() - self.minimum()))


class MainWindow(QMainWindow):
    SETTINGS_VIDEO = "session/video_path"
    SETTINGS_CAPTION = "session/caption_path"
    SETTINGS_TRACKS = "session/face_tracks_path"

    def __init__(self):
        super().__init__()

        self.setWindowTitle("Immersive Captions 2")
        self.resize(1420, 860)

        self.settings = QSettings("OpenAI", "ImmersiveCaptions2")

        self.video_path: Path | None = None
        self.caption_path: Path | None = None
        self.face_tracks_path: Path | None = None

        self.caption_model: CaptionModel | None = None
        self.caption_renderer: CaptionRenderer | None = None

        self.is_user_scrubbing = False
        self.duration_ms = 0
        self.last_session_status = "No session restored yet."

        self.player = QMediaPlayer(self)
        self.audio_output = QAudioOutput(self)
        self.player.setAudioOutput(self.audio_output)

        self.scene = QGraphicsScene(self)
        self.video_item = QGraphicsVideoItem()
        self.scene.addItem(self.video_item)
        self.player.setVideoOutput(self.video_item)

        self.view = QGraphicsView(self.scene)
        self.view.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.view.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.view.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.view.setFrameShape(QFrame.Shape.NoFrame)
        self.view.setStyleSheet("background:#0d0f14; border-radius: 12px;")

        self.open_video_button = QPushButton("Open Video")
        self.open_caption_button = QPushButton("Open Caption JSON")
        self.open_tracks_button = QPushButton("Open Face Tracks JSON")
        self.process_faces_button = QPushButton("Process Faces")
        self.toggle_debug_button = QPushButton("Hide Face Boxes")
        self.play_pause_button = QPushButton("Play / Pause")

        self.time_label = QLabel("00:00 / 00:00")
        self.time_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.seek_slider = ClickableSlider(Qt.Orientation.Horizontal)
        self.seek_slider.setRange(0, 0)

        self.video_value_label = QLabel("No video loaded")
        self.caption_value_label = QLabel("No caption loaded")
        self.tracks_value_label = QLabel("No face tracks loaded")

        self.playback_state_value_label = QLabel("Stopped")
        self.active_captions_value_label = QLabel("0")
        self.visible_faces_value_label = QLabel("0")
        self.scene_size_value_label = QLabel("0 × 0")
        self.current_frame_value_label = QLabel("-")
        self.sample_rate_value_label = QLabel("-")
        self.session_status_value_label = QLabel(self.last_session_status)
        self.session_status_value_label.setWordWrap(True)

        self.caption_renderer = CaptionRenderer(self.scene, None)

        self.ui_timer = QTimer(self)
        self.ui_timer.setInterval(33)

        self._build_ui()
        self._apply_style()

        self.open_video_button.clicked.connect(self.open_video)
        self.open_caption_button.clicked.connect(self.open_caption)
        self.open_tracks_button.clicked.connect(self.open_face_tracks)
        self.process_faces_button.clicked.connect(self.process_faces_for_current_video)
        self.toggle_debug_button.clicked.connect(self.toggle_debug_faces)
        self.play_pause_button.clicked.connect(self.toggle_play_pause)

        self.seek_slider.sliderPressed.connect(self.on_slider_pressed)
        self.seek_slider.sliderReleased.connect(self.on_slider_released)
        self.seek_slider.sliderMoved.connect(self.on_slider_moved)

        self.player.positionChanged.connect(self.on_position_changed)
        self.player.durationChanged.connect(self.on_duration_changed)
        self.player.playbackStateChanged.connect(self.on_playback_state_changed)
        self.player.mediaStatusChanged.connect(self.on_media_status_changed)
        self.player.errorOccurred.connect(self.on_player_error)

        self.ui_timer.timeout.connect(self.update_overlay)

        self.space_shortcut = QShortcut(QKeySequence(Qt.Key.Key_Space), self)
        self.space_shortcut.activated.connect(self.toggle_play_pause)

        self.update_loaded_file_labels()
        self.update_runtime_info()
        QTimer.singleShot(0, self.restore_last_session)

    def _build_ui(self) -> None:
        video_layout = QVBoxLayout()
        video_layout.setContentsMargins(0, 0, 0, 0)
        video_layout.setSpacing(10)
        video_layout.addWidget(self.view, stretch=1)

        slider_row = QHBoxLayout()
        slider_row.setSpacing(10)
        slider_row.addWidget(self.seek_slider, stretch=1)
        slider_row.addWidget(self.time_label)
        video_layout.addLayout(slider_row)

        video_panel = QWidget()
        video_panel.setLayout(video_layout)

        side_layout = QVBoxLayout()
        side_layout.setContentsMargins(0, 0, 0, 0)
        side_layout.setSpacing(12)

        files_group = QGroupBox("Files")
        files_layout = QVBoxLayout()
        files_layout.setSpacing(8)
        files_layout.addWidget(self.open_video_button)
        files_layout.addWidget(self.open_caption_button)
        files_layout.addWidget(self.open_tracks_button)
        files_layout.addWidget(self.process_faces_button)
        files_group.setLayout(files_layout)

        loaded_group = QGroupBox("Loaded Resources")
        loaded_layout = QVBoxLayout()
        loaded_layout.setSpacing(8)
        loaded_layout.addWidget(self._make_label_pair("Video", self.video_value_label))
        loaded_layout.addWidget(self._make_label_pair("Caption", self.caption_value_label))
        loaded_layout.addWidget(self._make_label_pair("Face Tracks", self.tracks_value_label))
        loaded_group.setLayout(loaded_layout)

        playback_group = QGroupBox("Playback & Overlay")
        playback_layout = QVBoxLayout()
        playback_layout.setSpacing(8)
        playback_layout.addWidget(self.play_pause_button)
        playback_layout.addWidget(self.toggle_debug_button)
        playback_group.setLayout(playback_layout)

        info_group = QGroupBox("Runtime Info")
        info_layout = QVBoxLayout()
        info_layout.setSpacing(8)
        info_layout.addWidget(self._make_label_pair("State", self.playback_state_value_label))
        info_layout.addWidget(self._make_label_pair("Visible Faces", self.visible_faces_value_label))
        info_layout.addWidget(self._make_label_pair("Active Captions", self.active_captions_value_label))
        info_layout.addWidget(self._make_label_pair("Current Frame", self.current_frame_value_label))
        info_layout.addWidget(self._make_label_pair("Video Size", self.scene_size_value_label))
        info_layout.addWidget(self._make_label_pair("Sample Step", self.sample_rate_value_label))
        info_group.setLayout(info_layout)

        session_group = QGroupBox("Session Restore")
        session_layout = QVBoxLayout()
        session_layout.addWidget(self.session_status_value_label)
        session_group.setLayout(session_layout)

        side_layout.addWidget(files_group)
        side_layout.addWidget(loaded_group)
        side_layout.addWidget(playback_group)
        side_layout.addWidget(info_group)
        side_layout.addWidget(session_group)
        side_layout.addStretch(1)

        side_panel = QWidget()
        side_panel.setLayout(side_layout)
        side_panel.setObjectName("sidePanel")
        side_panel.setMinimumWidth(320)
        side_panel.setMaximumWidth(380)

        root_layout = QHBoxLayout()
        root_layout.setContentsMargins(12, 12, 12, 12)
        root_layout.setSpacing(14)
        root_layout.addWidget(video_panel, stretch=1)
        root_layout.addWidget(side_panel)

        container = QWidget()
        container.setLayout(root_layout)
        self.setCentralWidget(container)

    def _apply_style(self) -> None:
        self.setStyleSheet(
            """
            QMainWindow, QWidget {
                background: #12151c;
                color: #e8ecf3;
                font-size: 13px;
            }
            QGroupBox {
                border: 1px solid #2c3342;
                border-radius: 10px;
                margin-top: 10px;
                padding-top: 10px;
                background: #171b24;
                font-weight: 600;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 6px 0 6px;
                color: #b7c0d4;
            }
            QPushButton {
                background: #232a36;
                border: 1px solid #364056;
                border-radius: 8px;
                padding: 10px 12px;
                text-align: left;
            }
            QPushButton:hover {
                background: #2b3444;
            }
            QPushButton:pressed {
                background: #1d2430;
            }
            QLabel {
                color: #e8ecf3;
            }
            QSlider::groove:horizontal {
                border: 0px;
                height: 6px;
                background: #293241;
                border-radius: 3px;
            }
            QSlider::handle:horizontal {
                background: #7bb3ff;
                width: 14px;
                margin: -5px 0;
                border-radius: 7px;
            }
            #sidePanel {
                background: transparent;
            }
            """
        )

    def _make_label_pair(self, title: str, value_label: QLabel) -> QWidget:
        row = QWidget()
        layout = QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        title_label = QLabel(f"{title}:")
        title_label.setStyleSheet("color:#9aa6bd;")
        title_label.setMinimumWidth(92)

        value_label.setWordWrap(True)
        value_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        layout.addWidget(title_label)
        layout.addWidget(value_label, stretch=1)
        return row

    def format_time(self, ms: int) -> str:
        total_seconds = max(0, ms // 1000)
        minutes = total_seconds // 60
        seconds = total_seconds % 60
        return f"{minutes:02d}:{seconds:02d}"

    def set_session_status(self, text: str) -> None:
        self.last_session_status = text
        self.session_status_value_label.setText(text)
        self.statusBar().showMessage(text, 4000)

    def remember_path(self, key: str, path: Path | None) -> None:
        if path is None:
            self.settings.remove(key)
            return
        self.settings.setValue(key, str(path.resolve()))

    def _path_from_settings(self, key: str) -> Path | None:
        value = self.settings.value(key)
        if not value:
            return None
        path = Path(str(value))
        if path.exists():
            return path
        return None

    def restore_last_session(self) -> None:
        restored = []
        missing = []

        video_path = self._path_from_settings(self.SETTINGS_VIDEO)
        caption_path = self._path_from_settings(self.SETTINGS_CAPTION)
        tracks_path = self._path_from_settings(self.SETTINGS_TRACKS)

        raw_video_value = self.settings.value(self.SETTINGS_VIDEO)
        raw_caption_value = self.settings.value(self.SETTINGS_CAPTION)
        raw_tracks_value = self.settings.value(self.SETTINGS_TRACKS)

        for raw_value, resolved in (
            (raw_video_value, video_path),
            (raw_caption_value, caption_path),
            (raw_tracks_value, tracks_path),
        ):
            if raw_value and resolved is None:
                missing.append(Path(str(raw_value)).name)

        if video_path is not None:
            self.load_video(str(video_path), remember=False)
            restored.append(video_path.name)
        if caption_path is not None:
            self.load_caption(str(caption_path), remember=False)
            restored.append(caption_path.name)
        if tracks_path is not None:
            self.load_face_tracks(str(tracks_path), remember=False)
            restored.append(tracks_path.name)

        if restored:
            msg = f"Restored: {', '.join(restored)}"
            if missing:
                msg += f" | Missing: {', '.join(missing)}"
            self.set_session_status(msg)
        elif missing:
            self.set_session_status(f"Previous files missing: {', '.join(missing)}")
        else:
            default_video = Path(__file__).resolve().parents[2] / "media" / "video" / "video.mp4"
            if default_video.exists():
                self.load_video(str(default_video), remember=False)
                self.set_session_status(f"No saved session. Loaded default video: {default_video.name}")
            else:
                self.set_session_status("No saved session found.")

    def reset_player_state(self):
        self.player.pause()
        self.player.setSource(QUrl())

        self.duration_ms = 0
        self.seek_slider.setRange(0, 0)
        self.seek_slider.setValue(0)
        self.time_label.setText("00:00 / 00:00")
        self.play_pause_button.setText("Play / Pause")
        self.is_user_scrubbing = False

        if self.caption_renderer is not None:
            self.caption_renderer.clear()

        self.scene.setSceneRect(0, 0, 1280, 720)
        self.video_item.setSize(self.scene.sceneRect().size())
        self.update_runtime_info()

    def load_video(self, file_path: str, remember: bool = True):
        self.video_path = Path(file_path)
        self.reset_player_state()
        self.player.setSource(QUrl.fromLocalFile(str(self.video_path)))
        self.player.pause()
        if remember:
            self.remember_path(self.SETTINGS_VIDEO, self.video_path)
        self.update_loaded_file_labels()
        self.update_runtime_info()
        self.update_window_title()
        self.ui_timer.start()

    def load_caption(self, file_path: str, remember: bool = True):
        self.caption_path = Path(file_path)
        self.caption_model = CaptionModel(self.caption_path)

        if self.caption_renderer is None:
            self.caption_renderer = CaptionRenderer(self.scene, self.caption_model)
        else:
            self.caption_renderer.clear()
            self.caption_renderer.caption_model = self.caption_model

        if self.face_tracks_path is not None:
            self.caption_renderer.set_face_tracks(self.face_tracks_path)

        if remember:
            self.remember_path(self.SETTINGS_CAPTION, self.caption_path)
        self.update_overlay()
        self.update_loaded_file_labels()
        self.update_runtime_info()
        self.update_window_title()

    def load_face_tracks(self, file_path: str, remember: bool = True):
        self.face_tracks_path = Path(file_path)
        if self.caption_renderer is not None:
            self.caption_renderer.set_face_tracks(self.face_tracks_path)
        if remember:
            self.remember_path(self.SETTINGS_TRACKS, self.face_tracks_path)
        self.update_overlay()
        self.update_loaded_file_labels()
        self.update_runtime_info()
        self.update_window_title()

    def open_video(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open Video",
            str(self.video_path.parent if self.video_path else ""),
            "Video Files (*.mp4 *.mov *.mkv *.avi *.webm);;All Files (*)",
        )
        if file_path:
            self.load_video(file_path)
            self.set_session_status(f"Loaded video: {Path(file_path).name}")

    def open_caption(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open Caption JSON",
            str(self.caption_path.parent if self.caption_path else ""),
            "JSON Files (*.json);;All Files (*)",
        )
        if file_path:
            self.load_caption(file_path)
            self.set_session_status(f"Loaded caption: {Path(file_path).name}")

    def open_face_tracks(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open Face Tracks JSON",
            str(self.face_tracks_path.parent if self.face_tracks_path else ""),
            "JSON Files (*.json);;All Files (*)",
        )
        if file_path:
            self.load_face_tracks(file_path)
            self.set_session_status(f"Loaded face tracks: {Path(file_path).name}")

    def process_faces_for_current_video(self):
        if self.video_path is None:
            QMessageBox.warning(self, "No video", "Open a video first.")
            return

        suggested_output = self.video_path.with_suffix(".face_tracks.json")
        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Face Tracks",
            str(suggested_output),
            "JSON Files (*.json)",
        )
        if not output_path:
            return

        QMessageBox.information(
            self,
            "Processing started",
            "Face processing is starting. This may take a while on long videos.",
        )

        try:
            process_video_faces(self.video_path, output_path, sample_every_n_frames=2)
            self.load_face_tracks(output_path)
            self.set_session_status(f"Processed and loaded face tracks: {Path(output_path).name}")
            QMessageBox.information(self, "Done", f"Saved face tracks to:\n{output_path}")
        except Exception as exc:
            QMessageBox.critical(self, "Processing failed", str(exc))

    def toggle_debug_faces(self):
        if self.caption_renderer is None:
            return
        self.caption_renderer.show_debug_faces = not self.caption_renderer.show_debug_faces
        self.toggle_debug_button.setText("Hide Face Boxes" if self.caption_renderer.show_debug_faces else "Show Face Boxes")
        self.update_overlay()

    def toggle_play_pause(self):
        if self.player.source().isEmpty():
            return
        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
        else:
            self.player.play()

    def on_slider_pressed(self):
        self.is_user_scrubbing = True

    def on_slider_moved(self, value: int):
        self.time_label.setText(f"{self.format_time(value)} / {self.format_time(self.duration_ms)}")
        self.update_runtime_info(position_override=value)

    def on_slider_released(self):
        self.is_user_scrubbing = False
        self.player.setPosition(self.seek_slider.value())
        self.update_overlay()

    def on_position_changed(self, position: int):
        if not self.is_user_scrubbing:
            self.seek_slider.setValue(position)
        self.time_label.setText(f"{self.format_time(position)} / {self.format_time(self.duration_ms)}")
        self.update_runtime_info(position_override=position)

    def on_duration_changed(self, duration: int):
        self.duration_ms = duration
        self.seek_slider.setRange(0, duration)
        self.time_label.setText(f"{self.format_time(self.player.position())} / {self.format_time(duration)}")
        self.update_runtime_info()

    def on_playback_state_changed(self, state: QMediaPlayer.PlaybackState):
        if state == QMediaPlayer.PlaybackState.PlayingState:
            self.play_pause_button.setText("Pause")
        else:
            self.play_pause_button.setText("Play")
        if state == QMediaPlayer.PlaybackState.PlayingState and not self.ui_timer.isActive():
            self.ui_timer.start()
        self.update_runtime_info()

    def on_media_status_changed(self, status: QMediaPlayer.MediaStatus):
        if status in (QMediaPlayer.MediaStatus.LoadedMedia, QMediaPlayer.MediaStatus.BufferedMedia):
            video_size = self.video_item.nativeSize()
            if video_size.width() > 0 and video_size.height() > 0:
                self.scene.setSceneRect(0, 0, video_size.width(), video_size.height())
                self.video_item.setSize(video_size)
                self.view.fitInView(self.scene.sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)
        self.update_runtime_info()

    def on_player_error(self, error, error_string: str):
        if error_string:
            self.set_session_status(f"Player error: {error_string}")

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if not self.scene.sceneRect().isEmpty():
            self.view.fitInView(self.scene.sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)

    def update_overlay(self):
        if self.caption_renderer is None:
            return
        current_time = self.player.position() / 1000.0
        self.caption_renderer.render(current_time)
        self.update_runtime_info()

    def update_loaded_file_labels(self) -> None:
        self._set_path_label(self.video_value_label, self.video_path, "No video loaded")
        self._set_path_label(self.caption_value_label, self.caption_path, "No caption loaded")
        self._set_path_label(self.tracks_value_label, self.face_tracks_path, "No face tracks loaded")

    def _set_path_label(self, label: QLabel, path: Path | None, empty_text: str) -> None:
        if path is None:
            label.setText(empty_text)
            label.setToolTip("")
            return
        label.setText(path.name)
        label.setToolTip(str(path.resolve()))

    def update_runtime_info(self, position_override: int | None = None) -> None:
        position_ms = self.player.position() if position_override is None else position_override
        playback_state = self.player.playbackState()
        if playback_state == QMediaPlayer.PlaybackState.PlayingState:
            state_text = "Playing"
        elif playback_state == QMediaPlayer.PlaybackState.PausedState:
            state_text = "Paused"
        else:
            state_text = "Stopped"
        self.playback_state_value_label.setText(state_text)

        current_time_seconds = position_ms / 1000.0
        visible_faces = 0
        current_frame_text = "-"
        sample_step = "-"

        if self.caption_renderer is not None and self.caption_renderer.face_tracks is not None:
            visible_faces = len(self.caption_renderer.face_tracks.get_all_bboxes(current_time_seconds))
            frame = self.caption_renderer.face_tracks.get_frame(current_time_seconds)
            if frame is not None:
                current_frame_text = str(frame.get("frame_index", "-"))

        if self.face_tracks_path is not None and self.caption_renderer is not None and self.caption_renderer.face_tracks is not None:
            metadata = self.caption_renderer.face_tracks.metadata
            sample_value = metadata.get("sample_every_n_frames")
            if sample_value is not None:
                sample_step = str(sample_value)

        active_captions = 0
        if self.caption_model is not None:
            active_captions = len(self.caption_model.get_active_sections(current_time_seconds))

        scene_rect = self.scene.sceneRect()
        self.visible_faces_value_label.setText(str(visible_faces))
        self.active_captions_value_label.setText(str(active_captions))
        self.scene_size_value_label.setText(f"{int(scene_rect.width())} × {int(scene_rect.height())}")
        self.current_frame_value_label.setText(current_frame_text)
        self.sample_rate_value_label.setText(sample_step)

    def update_window_title(self):
        video_name = self.video_path.name if self.video_path else "No Video"
        caption_name = self.caption_path.name if self.caption_path else "No Caption"
        tracks_name = self.face_tracks_path.name if self.face_tracks_path else "No Face Tracks"
        self.setWindowTitle(f"Immersive Captions 2 — {video_name} — {caption_name} — {tracks_name}")


def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
